using System.Collections;
using UnityEngine.Events;
using UnityEngine;
using UnityEngine.UI;
using TMPro;
using UnityEngine.SceneManagement;

public class UI_load_screen : MonoBehaviour
{
    [SerializeField] Slider teams_in_game_slid;
    [SerializeField] TextMeshProUGUI teams_in_game_text;
    [SerializeField] Slider worms_in_game_slid;
    [SerializeField] TextMeshProUGUI worms_in_game_text;
    [SerializeField] Button Start_game;
    [SerializeField] Button How_to_play;

    int worms_number;
    int teams_number;
    /* Pri na��tan� �al�ej sc�ny doch�dza k zmazaniu "star�ch" objektov a premenn�ch.
     * Preto potrbujeme uchova� vstup od u��vate�a pomocou knihovnej funkcie "OnDisable"
     a pomocou triedy "PlayerPrefs" */
    void OnDisable() // uchov�vanie hodn�t zo "sliderov� 
    {
        PlayerPrefs.SetInt("Worms_Number", worms_number);
        PlayerPrefs.SetInt("Teams_Number", teams_number);
    }
    void Start()
    {
        // z�skavanie hodn�t zo "sliderov" + zmena textu pri pou��van� "Sliderov"
        teams_in_game_slid.onValueChanged.AddListener((v) => 
        {
            teams_number = (int)v;
            teams_in_game_text.text = "Teams in game: " + v.ToString(); 
        });

        worms_in_game_slid.onValueChanged.AddListener((h) => 
        {
            worms_number = (int)h;
            worms_in_game_text.text = "Worms in team: " + h.ToString(); 
        });
        // Tla�itko Play na��ta �al�iu sc�nu --> Loading/Game Scena
        Start_game.onClick.AddListener(() => { Loader_of_scenes.Load(Loader_of_scenes.Scenee.Game_scene); });
        // Tla�itko How to Play na��ta �al�iu sc�nu --> Loading/Controls Scena
        How_to_play.onClick.AddListener(() => { Loader_of_scenes.Load(Loader_of_scenes.Scenee.Controls_scene); });
    }

}

public static class Loader_of_scenes
{
    private class Dummy_class : MonoBehaviour { } // Tato klassa je potrebn� preto�e "StartCourutine" 
    public enum Scenee { Main_Menu_Scene, Game_scene, Loading_scene, Controls_scene } // enum trieda pre mena r�znych scien
    private static UnityAction CallBackAction; // akcia ktor� je potrebn�  vykona� po update loadingu
    private static AsyncOperation async;
    public static void Load(Scenee scene)
    {
        // Nastavenie akcie na na��tanie cie�ovej "Scene"
        CallBackAction = () => 
        {
            // tento objekt sl��i k asynchronn�mu na��taniu
            GameObject loading_game_object = new GameObject("Loading Object"); 
            /* StartCoroutine znamen� �e z�skavanie stavu na��tania prebieha spolu s na��tan�m objektov.
             * Taktie� potrbujeme "pr�zdnu triedu" dummy preto�e trieda "loader_of_scenes" je staticka 
             a t� nem��e by� pou�it� ako argument.*/
            loading_game_object.AddComponent<Dummy_class>().StartCoroutine(LoadSceneAsync(scene));
        }; // toto je akcia ktor� sa ma vykona� 

        // Na��tanie "Loading scene"
        SceneManager.LoadScene(Scenee.Loading_scene.ToString());
    }

    private static IEnumerator LoadSceneAsync(Scenee scene) // kod je vykon�van� asynchronne cez niekolko framov
    {
        // po�ivam yield retunrn na minimaliz�ciu pam�te
        yield return null; // pred "loadingom"
        async = SceneManager.LoadSceneAsync(scene.ToString());  // "loading"
        while(!async.isDone) //dok�m nieje na��tanie hotov�
        { yield return null; }
    }

    public static float loading_progress_bar() // funkcia ktr� vracia progress na��tania hry
    { 
        if (async != null)
        {
            return async.progress;
        }
        return 0F;
    }

    public static void CallBack()
    {
        // tuto funkciu vol� "Loading scene" aby zavolalo "Akciu" na��taj cie�ov� "Scene"
        if (CallBackAction != null)
        {
            CallBackAction(); // vykonaj akciu ak u� je pripraven�
            CallBackAction = null;
        }
    }
}
