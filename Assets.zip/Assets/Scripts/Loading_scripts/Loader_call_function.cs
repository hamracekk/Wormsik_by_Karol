using UnityEngine;

public class Loader_call_function : MonoBehaviour
{
    private bool First_Update = true;

    private void Update()
    {
        if (First_Update)
        {
            First_Update = false;
            Loader_of_scenes.CallBack(); // funkcia bude volan� len prv� update
        }
    }
}
