using TMPro;
using UnityEngine;
using UnityEngine.UI;

public class Loading_screen_bar : MonoBehaviour
{
    // komunik�cia s grfick�mi objektami a kamerou
    [SerializeField] Image img;
    [SerializeField] TextMeshProUGUI loading_text;
    [SerializeField] Camera cam;

    private void Update()
    { 
        img.fillAmount = Loader_of_scenes.loading_progress_bar(); // obrazok sa plni pod� toho ako �aleko je proces na��tania
        loading_text.text = "Loading:  " + (img.fillAmount*100) + "%"; // Zmena textu --> na��tavanie v percent�ch
    } 
}
