using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

//pomocn� enum trieda pre typy blokov mapy
public enum ground { grass = 1, stone = 2, dirt = 3, air = 4, cave = 5 };
public class Procedural_Gen : MonoBehaviour
{
    public int width = 620; // polovica ��rky mapy
    public int height = 400; // polovica v��ky mapy
    public int thickness_of_X_wall = 30; // limit X pre "perlinoise" funkciu (Nechceme aby steny jaskyne zasahovali cez okraj mapy)
    public int thickness_of_y_wall = 60;  // limit Y pre "perlinoise" funkciu (Nechceme aby steny jaskyne zasahovali cez okraj mapy)
    private static float heightValue = -100; //Do akej v��ky ba mala by� genrovan� zem ?
    private float smoothnes = 100; // jemnos� funkcie perlinoise
    private int RandomFillPercent = 48; // value from 0 to 100
    private int Min_stone_height = 44; 
    private int Max_stone_height = 25;
    private int Grass_thickenss = 4;
    [SerializeField] Tilemap DirtTileMap, GrassTileMap, StoneTileMap, AirTileMap, CaveTileMap; // 5 typov blokov
    [SerializeField] RuleTile Dirt, Grass, Stone, Air, Cave; 
    //Tento slovn�k obsahuje (x,y) klu�e a hodnoty ktor� odpovedj� typu blokov mapy (stone, grass, dirt...)
    public Dictionary<(int, int), ground> dictionary_for_collision_with_ground = new Dictionary<(int, int), ground>();
    private int[] perlinois_heights; // Ukladanie v��ky n�hodnej gener�cie zeme 
    public ground[,] map_pixels; // reprezentacia mapy 

    void Start()
    {
        map_pixels = new ground[2 * width, 2 * height]; //Inicializ�cia pola ktor� "vie" ako vyzer� mapa
        perlinois_heights = new int[2 * width]; // mapa m� �irku 2*width
        Generation(); //Gener�cia ostrov�ekov a zeme pomocou funkcie "perlinnoise"
        Smooth_method(10);
        Initialize_map_with_tile();
    }
    //Metoda ktor� vyhladzuje n�hodn� gener�ciu jask��
    private void Smooth_method(int smooth_count)
    {
        for (int i = 0; i < smooth_count; i++) // kolko kr�t chcem vyhladzova� gener�ciu jask��
        for (int x = 0; x < 2*width; x++)
        {
            for (int y = 0; y < perlinois_heights[x] + height; y++) // x,y s� index do po�a
            {
                int x_coordinate = x - width;
                int y_coordinate = y - height;
                (int, int) dict_key = (x_coordinate, y_coordinate);
                if (x <= thickness_of_X_wall || (x>2*width-thickness_of_X_wall) ||
                    y<= thickness_of_y_wall  || (y > perlinois_heights[x] + height - thickness_of_y_wall))
                { map_pixels[x, y] = dictionary_for_collision_with_ground[dict_key]; } // nastavovanie stien mapy
                else
                {
                    int neighbour_count = Count_neighbours(x,y, perlinois_heights[x] + height);
                    if (neighbour_count > 4) //Je to nejk� typ ulo�en� v slovn�ku (preto potrebujeme slovn�k)
                    {
                            map_pixels[x, y] = dictionary_for_collision_with_ground[dict_key];
                    }
                    else if(neighbour_count < 4) // je to jasky�a
                    {
                            map_pixels[x, y] = ground.cave;
                    }
                }
            }
        }
    }

    //pomocn� funkcia ktor� po��ta pixely nejak�ho typu "zeme" okolo dan�ho pixelu 
    private int Count_neighbours(int x_pos, int y_pos, int ground_height) // maticov� koordinay pixelu
    {
        int ground_count = 0;
        for (int x_neighbour = x_pos - 1 ; x_neighbour <= x_pos + 1; x_neighbour++) // skenovanie okolie pixelu
        {
            for (int y_neighbour = y_pos - 1; y_neighbour <= y_pos + 1; y_neighbour++)
            {
                if (x_neighbour >= 0 && x_neighbour < 2 * width &&
                    y_neighbour >= 0 && y_neighbour < ground_height) // len vn�tri bariery mapy*/
                {
                    if (x_neighbour != x_pos || y_neighbour != y_pos) // okrem s��asn�ho pixelu
                    {
                        if (map_pixels[x_neighbour, y_neighbour] == ground.grass ||
                            map_pixels[x_neighbour, y_neighbour] == ground.dirt ||
                            map_pixels[x_neighbour, y_neighbour] == ground.stone)
                        { ground_count++; }
                    }
                }
            }
        }
        return ground_count;
    }
    void Generation()
    {
        int seed = -1000;
        //n�hodn� hodnota v z�vislosti na seede
        System.Random randomizer = new System.Random(seed.GetHashCode());

        for (int x = -width; x < width; x++)
        {
            // Perlinoise gener�cia ter�nu
            int Hei = (int)( heightValue * Mathf.PerlinNoise( (x + width) / smoothnes, seed));
            perlinois_heights[x + width] = Hei; // ukladam maximum y (po ktor� sa bude generaova�)

            //perlinoise funkcia pre ostrov�eky
            int Island_Hei = (int)(heightValue * Mathf.PerlinNoise( (3/2)*((x + width) / smoothnes), seed)); 

            //distrib�cia blokov typu "stone"
            int min_stone = Hei - Min_stone_height;
            int max_stone = Hei - Max_stone_height;
            int stone_spawn = Random.Range(min_stone, max_stone);


            // ukladanie pixelov na odpovedaj�ce poz�cie (podla y - s�radnice) a ich ukladanie do slovn�ka
            for (int y = -height ; y < height; y++)
            {
                // transform�cia z koordinatov do indexov matice
                int x_matrix_index = x + width; 
                int y_matrix_index = y + height; 

                if (y >=  80 && y <= 200 + Island_Hei && // gener�cia ostrov�ekov
                    Mathf.Abs(x) >= (thickness_of_X_wall + 80) && Mathf.Abs(x)<= 450 + thickness_of_X_wall)
                {
                    map_pixels[x_matrix_index, y_matrix_index] = ground.grass;
                    dictionary_for_collision_with_ground[(x, y)] = ground.grass;
                }
                else if (y < Hei) // Rozli�n� typy "zeme"
                {
                    int random_val = randomizer.Next(1, 100);
                    ground type_of_ground = ground.dirt;

                    if (y < stone_spawn)
                    { type_of_ground = ground.stone; } // pr�pad pix�lu typu kamen
                    else if (y < Hei - Grass_thickenss && y >= stone_spawn)
                    { type_of_ground = ground.dirt; } // pr�pad pix�lu typu zemina
                    else { type_of_ground = ground.grass; } // pr�pad pix�lu typu tr�va

                    dictionary_for_collision_with_ground[(x, y)] = type_of_ground;
                    //pomocn� slovn�k (m��me porovn�va� hodnoty v slovn�ku a poli aby sme ur�ili ak� pixel bol ak�ho typu "zeme" pred gener�ciou jask��)
                    map_pixels[x_matrix_index, y_matrix_index] = type_of_ground;

                    if (random_val > RandomFillPercent)
                    {
                        map_pixels[x_matrix_index, y_matrix_index] = ground.cave; //ukladanie typu pixelu
                    }
                }
                else { map_pixels[x_matrix_index, y_matrix_index] = ground.air; }
            }
        }
    }

    private void Initialize_map_with_tile() // grafick� inicializ�cia pixelov mapy
    {
        for (int i = 0; i < map_pixels.GetLength(0); i++)
        {
            for (int j = 0; j < map_pixels.GetLength(1); j++)
            {
                int x_pos_real_world = i - width;
                int y_pos_real_world = j - height;
                ground gr = map_pixels[i, j];
                Vector3Int tile_vector = new Vector3Int(x_pos_real_world, y_pos_real_world, 0);
                switch (gr)
                {
                    case ground.grass:
                        GrassTileMap.SetTile(tile_vector, Grass);
                        break;
                    case ground.stone:
                        StoneTileMap.SetTile(tile_vector, Stone);
                        break;
                    case ground.dirt:
                        DirtTileMap.SetTile(tile_vector, Dirt);
                        break;
                    case ground.air:
                        AirTileMap.SetTile(tile_vector, Air);
                        break;
                    case ground.cave:
                        CaveTileMap.SetTile(tile_vector, Air);
                        break;
                }
            }
        }
    }
}
