using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public class Team_object // Trieda ktor� zdru�uje worms�kov do t�mov
{
    private int team_size = 0;
    public List<WORM> worms_in_team = new List<WORM>(); // List worms�kov v jednom t�me
    private int current_worm_index = 0; // Index worms�ka ktor� pr�ve reprezentuje t�m (focus)

    public Team_object(int team_size)
    {
        this.team_size = team_size;
    }

    public bool is_team_alive() // Je t�m na �ive ?
    {
        int Alive_members = 0;
        for (int i = 0; i < worms_in_team.Count; i++)
        { if (worms_in_team[i].current_health_progress > 0.0F) Alive_members++; }
        if (Alive_members > 0) { return true; }
        return false;
    }

    public WORM return_next_member() // funkcia ktor� vracia �al�ieho �iv�ho worms�ka v t�me
    {
        current_worm_index++;
        current_worm_index %= team_size;
        while (worms_in_team[current_worm_index].current_health_progress == 0F)
        { 
            current_worm_index++;
            current_worm_index %= team_size;
        }
        return worms_in_team[current_worm_index]; // vr�ti �al�ieho �lena
    }
}
public enum Action  // Enum pre akciu po "smrti" a rozpoznanie fyzik�lnych objektov r�znych typov
{ Nothing = 0, Booom = 30, Debri }
public abstract class Physics_object : MonoBehaviour
{
    //Atrib�ty fyzick�ch objektov
    public float X_pos = 0F;
    public float Y_pos = 0F;
    public float X_velocity = 0F;
    public float Y_velocity = 0F;
    public float X_acceleration = 0F;
    public float Y_acceleration = 0F;

    public float radius_of_interaction;
    public bool Stable = true;
    public float friction = 1;

    //Ko�ko kr�t pred "zmazan�m" objektu m��e d��js� k odrazu ??
    public int Bounce_number = -1;
    //Je potrebn� tento objekt odstr�ni� ?
    public bool Is_dead = false;

    //Metoda ktor� ma�e objekty zo sc�ny
    abstract public void Dispose();
    //Pohyb objektov
    abstract public void move_method(float x_vec, float y_vec);

    //�o by malo nasta� po "smrti" objektu ?
    abstract public Action Dead_action();

    // funkcia zodpovedn� za rot�ciu objektu
    abstract protected void rotate(float Y_vel, float X_vel);
}
public enum GameState //R�zne stavy hry
{
    Reset_state, Allocate_Worms,
    Proces_of_Alllocating, Start_state, Camera_state,
    Game_Over_state
}

//"Main_function" komunikuje s objektom "Ph_engine"t (actualize list of physics objects) 
// A taktie� s objektami Worm, Team, Missel, Debri 
public class Main_function : MonoBehaviour
{
    [SerializeField] Sprite[] worm_aiming;
    [SerializeField] Sprite base_sprite;
    [SerializeField] WORM new_worm;
    [SerializeField] Debri_object debri;
    [SerializeField] Bomb_object bomb;
    [SerializeField] RuleTile Air;
    SpriteRenderer worm_sprite_render; // Objekt ktor� uchov�va obr�zky a trsnform�cie obr�zku
    public GameState Current_state, Next_state;  // S��asn� stav hry
    private Procedural_Gen Map_object; // Komun�k�cia s objektom mapy
    private Ph_engine engine; // Komun�k�cia s objektom "physics engine"
    public Camera_follow_script cam; // Komun�k�cia s objektom "Camera";
    public WORM Under_control = null; // Ktor� worms�k je pr�ve pod kontrolou ? (physics_object)
    private Animator animator;  // Objekt ktor� zaobstar�va logiku anim�ci�
    private Tilemap Dirt_map, Grass_map, Stone_map, Air_map, Cave_map;
    private float Prev_time = 0; //�as predch�dzaj�ceho updatu
    public bool GameIsStable = false; // s� v�etky objekty stabiln� ?
    public bool PlayerHasControl = false;
    public bool PlayerCompletedAction = false;
    public int number_of_teams ; //Po�et t�mov v hre
    public int number_of_worms_in_team; //po�et worms�kov v jednom t�me
    public List<Team_object> Teams_in_game; //List t�mov 
    private int player_on_move; // ��slo hr��a ktor� je pr�ve na "�ahu"
    // flagy pre r�zne anim�cie
    private bool walking = false;
    private bool jumping = false;
    private bool jetpacking = false;
    private bool gun_is_pulled = false;
    private bool punching = false;
    private bool vert_flame = false;

    void OnEnable() // z�skavanie hodn�t z "Main Menu" sc�ny (nastaven� hodnoty pomocou "sliderov")
    {
        number_of_teams = PlayerPrefs.GetInt("Teams_Number"); // po�et t�mov v hre
        if (number_of_teams == 0) // pr�pad kedy hr�� nezvolil pomocou "slideru" po�et t�mov 
            number_of_teams = 2;

        number_of_worms_in_team = PlayerPrefs.GetInt("Worms_Number"); // po�et worms�kov v jednom t�me
        if (number_of_worms_in_team == 0) // pr�pad kedy hr�� nezvolil pomocou "slideru" po�et worms�kov v t�me 
            number_of_worms_in_team = 1;
    }
    void Start()
    { 
        Current_state = GameState.Reset_state; //setting the starting state of game
        Prev_time = Time.time; //setting the time of user control handler
        Teams_in_game = new List<Team_object>(); // Inicializing the list
    }
    private void Awake()
    {
        // reference na r�zne objekty
        Map_object = GameObject.Find("Procedural_generation").GetComponent<Procedural_Gen>();
        engine = GameObject.Find("Physic_engine").GetComponent<Ph_engine>();
        cam = GameObject.Find("Main Camera").GetComponent<Camera_follow_script>();
        Dirt_map = GameObject.Find("Dirt").GetComponent<Tilemap>();
        Stone_map = GameObject.Find("Stone").GetComponent<Tilemap>();
        Grass_map = GameObject.Find("Grass").GetComponent<Tilemap>();
        Air_map = GameObject.Find("Air").GetComponent<Tilemap>();
        Cave_map = GameObject.Find("Cave").GetComponent<Tilemap>();
        engine.main = this; //pred�vanie reference
        cam.main = this;
    }
    void Update() //Toto je hlavn� "while loop" tejto hry --> logika vstupov od u�ivatela
    {
        bool timer_out = cam.Timer_is_out(); // vypr�al �as kola ?
        GameIsStable = engine.Check_if_objects_are_stable(); // Kontrola stability objektov
        if (Under_control != null) { Under_control.arrow_blicking(); } // �ipka ukazuj�ca na vybran�ho worms�ka

        switch (Current_state) // R�zne stavy hry
        {
            case GameState.Reset_state: // Prv� stav hry
                Next_state = GameState.Allocate_Worms;
                PlayerHasControl = false; // hra� nem� kontrolu
                break;

            case GameState.Allocate_Worms: // Rozmiestnenie wormsikov na mape
                cam.actualize_list_of_colors(); // Inicializ�cia listu farieb pre t�my
                Initialize_teams_of_worms(); // Inicializ�cia t�mov
                cam.Initialize_names(); // Inicializ�cia textu na obrazovke
                PlayerHasControl = false; // hr�� zatia� nem� kontrolu nad vstupom
                Next_state = GameState.Proces_of_Alllocating; // Nastavovanie �al�ieho stavu hry
                break;

            case GameState.Proces_of_Alllocating:
                PlayerHasControl = false; // hr�� st�le nem� kontrolu
                if (GameIsStable) // jednotky worms�kov padaj� a hra "�ak�" k�m sa v�etko stabilizuje
                {
                    player_on_move = -1;
                    change_player(); // Zemna hr��a ( z -1 na 0) a rsetovanie flagov  + nstavovanie "focusu" kamery                                      
                    PlayerCompletedAction = false;
                    Next_state = GameState.Start_state;
                    PlayerHasControl = true; // Sp��tame kontrolu nad hrou
                    cam.Reset_timer(); // Resetujeme timer za kolo
                }
                break;

            case GameState.Start_state:
                if (PlayerCompletedAction || timer_out) // ak hra� urobil akciu alebo ak mu vypr�al �as
                {
                    Under_control.arrow_blicking(); // nastvovanie ��pky nad worms�kom
                    Next_state = GameState.Camera_state; // Tak �al�� stav je stav kedy hr�� sleduje "d�sledky" svojej akcie
                }
                break;

            case GameState.Camera_state:
                PlayerHasControl = false; // Hr�� v tomto re�ime nem� kontrolu nad hrou
                PlayerCompletedAction = false; // resetovanie flagu
                if (GameIsStable) // ak sa v�tko stabilizuje tak m��me zmeni� hr��a
                {
                    int last_player_on_move = player_on_move; // Aktualiz�cia hr��a
                    change_player(); // Zmena hr��a
                    Next_state = GameState.Start_state; // Prepnutie do "Start" stavu
                    PlayerHasControl = true; // Pred�vame kontrolu hr��ovy
                    if (last_player_on_move == player_on_move || Someone_won()) // Kontrolujeme �i je koniec hry
                    {
                        Next_state = GameState.Game_Over_state;
                    }
                    else
                    { cam.Reset_timer(); } // Resetujeme �asova� pre nov� kolo
                }
                break;
            case GameState.Game_Over_state:
                Next_state = GameState.Game_Over_state;
                cam.Call_Game_Over_Text(player_on_move); // Text po skon�en� hry, ktor� hovr� ktor� hr�� vyhral
                PlayerHasControl = false;
                break;
        }
        if (!timer_out) { cam.Actualize_timer();  } // Aktualiz�cia �asu 

        if (PlayerHasControl) // Z�skavanie vstupu od hr��a
        {
            float horizontal_input = Input.GetAxis("Horizontal"); // do prva/�ava

            if (GameIsStable)
            {

                jumping = false; // Ak je hra stabiln� m��me resetova� flag "skosku"
                animator.SetBool("Flying", jumping); // Nastavovanie objektu anim�ci�

                if (Input.GetKeyUp(KeyCode.Z)) { cam.Resize(); } // Zomm In / Zoom out kamery

                if (horizontal_input > 0.01F && !gun_is_pulled) // pohyb do prava
                {
                    Under_control.X_velocity = 3F;
                    Under_control.Y_velocity = 2.5F; // musime udeli� r�chlos� proti "gravita�nej" r�chlosti
                    Under_control.transform.localScale = new Vector3(-10, 10, 1); // zrkadlov� trnasform�cia obr�zka
                }
                else if (horizontal_input < -0.01F && !gun_is_pulled) // pohyb do prava
                {
                    Under_control.transform.localScale = new Vector3(10, 10, 1);
                    Under_control.X_velocity = -3F;
                    Under_control.Y_velocity = 2.5F;  // musime udeli� r�chlos� proti "gravita�nej" r�chlosti
                }

                walking = horizontal_input != 0 && !gun_is_pulled && !jetpacking && !punching && !vert_flame;
                animator.SetBool("Walking", walking); // Nastavoanie objektu anim�ci� pre "ch�dzu"
            }

            if (Input.GetKeyUp(KeyCode.C) && !gun_is_pulled && !jetpacking && !punching && !vert_flame)
                change_wormsik() ;// zmena wormsika v jednom t�me


            if (Input.GetKeyDown(KeyCode.UpArrow) && !gun_is_pulled && !punching && !vert_flame) 
            {
                if (Under_control.Y_velocity < 5F && !jumping && !jetpacking) // Podmienka pre skok 
                {
                    Under_control.Y_velocity += 8; // Pridanie r�chlosti "proti gravit�ci�"
                    jumping = true; // Aktualiz�cia flagu
                }
                else if (jetpacking)  // hra� ma nasaden� jetpack
                { 
                    Under_control.Y_velocity += 8;
                    animator.SetBool("JetPack_fly", true);  // nastavenie objektu anim�ci� na "jetpack" anim�ciu
                } 
            }

            // Vstup u�ivate�a na vykonanie skoku
            if ( jumping && !jetpacking && !gun_is_pulled && !vert_flame && punching) 
                animator.SetBool("Flying", true);


            // wormsik si nasadzuje jet_pack ak nerob� in� akciu a ak ho e�te nepou�il
            if (Input.GetKeyUp(KeyCode.Alpha1) && !jumping && !gun_is_pulled && !punching && !vert_flame)
                jet_pack_function();

            if (jetpacking) // ovladanie jetpacku
            {
                if (horizontal_input > 0.01F) // pohyb do prava
                {
                    Under_control.X_velocity = 5F;
                    Under_control.transform.localScale = new Vector3(-10, 10, 1);
                }
                else if (horizontal_input < -0.01F) // pohyb do �ava
                {
                    Under_control.transform.localScale = new Vector3(10, 10, 1);
                    Under_control.X_velocity = -5F;
                }
                animator.SetBool("JetPack_fly", true);
            }

            if (Input.GetKeyDown(KeyCode.Alpha2)) // Control key pre zbar� "DELO" 
            {
                animator.SetBool("Pulling", true);
                gun_is_pulled = true; // hra� sa nesmie h�ba�
            }

            // wormsik spustil "vertical flame" ak nerob� in� akciu a ak ho e�te nepou�il
            else if (Input.GetKeyUp(KeyCode.Alpha3) && !jumping && !gun_is_pulled && !jetpacking && !Under_control.vertcal_flame_used && !punching)
            {
                vert_flame = true;
                Under_control.vertcal_flame_used = true;
                vertical_flame(); // funkce ktor� zhadzuje vertical flame
                PlayerCompletedAction = true; // hr�� vyu�il vertical flame tak�e sa skon�ilo jeho kolo
            }

            // vstup pre "punching" akciu 
            else if (Input.GetKeyUp(KeyCode.Alpha4) && !jumping && !gun_is_pulled && !jetpacking && !vert_flame)
            {
                punching = true; // nastavenie flagu
                animator.SetBool("Punching", true); // anstavenie anim�cie
                // zni�enie �ivota worms�kov ktor� s� v blizkosti n�ho worms�ka
                decrease_health_of_worms_in_proximity(Under_control.X_pos, Under_control.Y_pos, 30, "punching");
            }
            if (punching && animator.GetCurrentAnimatorStateInfo(0).IsName("Punching")) // ak nieje v bl�zkosti �iaden wormik tak po�k�me na koniec anim�cie
                PlayerCompletedAction = true;

            bool animation_of_pulling = animator.GetCurrentAnimatorStateInfo(0).IsName("Pulling_gun"); // flag --> anim�cia dohrala ?
            if (gun_is_pulled && animation_of_pulling) // Pr�pad kedy wormsik zameriava
            {
                if (!Under_control.firing_the_weapon) // Ak projektil e�te nevystrelil (tak zameriavame)
                    animation_of_aiming(); // vol�m funkciu ktor� je zodpovedn� za nim�ciu mierenia zbrane

                if (Input.GetKeyDown(KeyCode.Space))
                {
                    Under_control.loading_shooting = true; // hr�� na�ahuje zbra�
                    Under_control.current_fire_progress = 0; // resetovanie energie na�ahovania zbrane
                    Under_control.firing_the_weapon = false; // resetovanie flagu "zbar� u� vyp�lila"
                    Prev_time = Time.time;  //ukladanie posledn�ho �asov�ho r�mcu
                }

                if (Input.GetKey(KeyCode.Space)) // dr�anie tla��tka space zvy�uje energiu v�strelu
                {
                    if (Under_control.loading_shooting)
                    {
                        float intgration_time = Time.time - Prev_time; //integra�n� �asov� usek
                        Under_control.current_fire_progress = 70F * intgration_time; //�asov� integr�cia dr�ania tla��tka
                        if (Under_control.current_fire_progress >= 100F)
                        {
                            Under_control.current_fire_progress = 100F; // maxim�lna energia v�strelu
                            Under_control.firing_the_weapon = true; //automaticky d�jde k vyp�leniu
                        }
                    }
                }

                if (Input.GetKeyUp(KeyCode.Space)) // vypustenie projektilu s danou energiou
                {
                    if (Under_control.loading_shooting)
                    { Under_control.firing_the_weapon = true; } // Teraz je �as vypustenia projektilu
                    Under_control.loading_shooting = false;
                }

                if (Under_control.firing_the_weapon) // Case of the weapon projectil launching
                {
                   // worm_sprite_render.sprite = base_sprite;
                    animator.enabled = true;// znovu zapnutie anim�toru
                    reset_animator();
                    /* Funkcia zodpovedn� za v�po�et parametrov projektilu ako pozicia, r�chlos� a pod. 
                     * Taktie� je zodpovedn� za update listu fyzick�ch objektov a vytvorenie instancie
                     * typu bomb_object */
                    Calculate_trajectory_and_update_list();
                    Under_control.firing_the_weapon = false;
                    Under_control.current_fire_progress = 0F;
                    Under_control.loading_shooting = false;
                    PlayerCompletedAction = true; // Hra� v�strelom ukon�il svoje kolo
                }
            }
        }
        Current_state = Next_state; // Aktualiz�cia stavu hry na �al�� "frame"
    }
    void spawn(Physics_object obj, int x_pos, int y_pos)
    {
        obj = Instantiate(obj, new Vector3(x_pos, y_pos,2), Quaternion.identity);
        obj.transform.parent = this.transform;
        obj.X_pos = x_pos;
        obj.Y_pos = y_pos;
        obj.Stable = false;
        //updating list of physical objects
        engine.Update_list(obj);
    }
    public void Bomb_function(Physics_object object_p) // funkcia bomby pri kolizi
    {
        Bomb_object bomb_B = object_p.GetComponent<Bomb_object>(); // z�skavanie referencie na objekt bomby
        // vytv�ranie kr�teru s polomerom odpovedaj�ci sile typu bomby
        Create_damage((int)bomb_B.X_pos,(int)bomb_B.Y_pos, bomb_B.radius_of_efect);
        //Zn�enie �ivota wormsikov v jednotliv�ch t�moch sp�soben� v�buchom
        decrease_health_of_worms_in_proximity(bomb_B.X_pos, bomb_B.Y_pos, bomb_B.radius_of_efect, "bomb");
        //vytvorenie �lomko po v�buch
        for (int i = 0; i < (int)bomb_B.radius_of_efect; i++)
            { spawn(debri, (int)bomb_B.X_pos, (int)bomb_B.Y_pos); }
    }
    private void vertical_flame() // funkcia zbrane vertical flame
    {
        int index_of_team_to_attack = Random.Range(0, number_of_teams); // ciel --> t�m vyberame n�hodne spravodlivo
        Team_object team_to_attack = Teams_in_game[index_of_team_to_attack];
        bool team_alive = team_to_attack.is_team_alive(); // Je team na �ive ?
        //mus�me sa uisti� �e team je na�ive a �e nevyber�me za cie� svoj team
        while (index_of_team_to_attack == player_on_move || !team_alive)
        {
            index_of_team_to_attack = Random.Range(0, number_of_teams);
            team_to_attack = Teams_in_game[index_of_team_to_attack];
            team_alive = team_to_attack.is_team_alive();
        }

        int number_of_worm = Random.Range(0, number_of_worms_in_team); // ciel --> wormsik v cielovom t�me je zase n�hodn�
        while(team_to_attack.worms_in_team[number_of_worm].worm_is_dead) // mus�me vybra� �iv� cie�
            number_of_worm = Random.Range(0, number_of_worms_in_team);

        float x_pos_to_send = team_to_attack.worms_in_team[number_of_worm].X_pos; // kde po�leme vertical flame ?
        float y_pos_to_send = Map_object.height - 10; // y - ov� pozice vzniku objektu
        // sada b�mb typu vetical flame rozmiestnen�ch symstricky okolo suradnice "x_pos_to_send "
        int distance_between_two = 30; //x - vzdialenos� medzi 2�ma susedn�mi vertical flame
        int number_of_flames = 7; // po�et bomb typu vertical flame
        for (int i= 0; i <= number_of_flames - 1; i++) 
        {
            float x_pos = (x_pos_to_send - distance_between_two* (number_of_flames - 1)/2) + i * distance_between_two; // v�po�et poz�cie jednotliv�ch vertical flame
            if (Map_object.width > Mathf.Abs(x_pos)) // kontrola na hranice mapy
            {
                Bomb_object vertical_flame = Instantiate(bomb, new Vector3(x_pos, Map_object.height - 10, -2), Quaternion.identity); //vytvorenie instancie
                vertical_flame.Tag = types_of_bomb.Vertical_flame; // potrebn� pre rozdielnu akciu na konci a taktie� rozdielnu anim�ciu
                vertical_flame.X_pos = x_pos;
                vertical_flame.Y_pos = y_pos_to_send;
                vertical_flame.Stable = false;
                engine.Update_list(vertical_flame); // Updatujeme list fyzick�ch objektov

                if (i == (number_of_flames - 1) / 2) // kamerou trackujeme prostredn� vertical flame
                {
                    Physics_object projectile = vertical_flame.GetComponent<Physics_object>();
                    cam.Update_object_to_track(projectile); // focus kamery na prostredn� vertical flame
                }
            }
        }
    }
    private void decrease_health_of_worms_in_proximity(float X_pos, float Y_pos, float radius, string effect_tag)
    {
        foreach (Team_object t in Teams_in_game)
        {
            foreach (WORM w in t.worms_in_team)
            {
                // v�po�et vzdialenosti od epicentra efektu
                float distance_X_from_obj = w.X_pos - X_pos;
                float distance_Y_from_obj = w.Y_pos - Y_pos;
                float euklid_dist = Mathf.Sqrt(distance_X_from_obj * distance_X_from_obj + distance_Y_from_obj * distance_Y_from_obj);
                //objekt je v bl�zkosti efektu, tak�e zmen�me jeho �ivot a kinetiku
                if (euklid_dist < radius)
                {
                    switch (effect_tag)
                    {
                        case "bomb":
                            // V�po�et zlo�iek r�chlosti v z�vislosti na vzdialenosti od efektu
                            w.X_velocity = (distance_X_from_obj / euklid_dist) * radius;
                            w.Y_velocity = (distance_Y_from_obj / euklid_dist) * radius;
                            /* Keby sa nahodou stalo �e del�m nulou tak udel�m worms�kovi nahodnu r�chlos�.
                             * To m��e nasta� pr�ve vtedy ak polomer interakcie objektu bomby a worms�ka je rovnak�.
                             * Vtedy sa m��e sta� �e  pri v�strele "pod seba je euklidovsk� vzdialenos� 0-v�*/
                            if (float.IsNaN(w.X_velocity) || float.IsNaN(w.Y_velocity)) 
                            {
                                w.X_velocity = Random.Range(-7,8);
                                w.Y_velocity = Random.Range(-7, 8);
                            }
                            float health_taken = Mathf.Sqrt(w.X_velocity * w.X_velocity + w.Y_velocity * w.Y_velocity); // strata �ivota sp�soben� efektom
                            w.Actualize_health(health_taken); // Aktualiz�cia �ivota worms�ka
                            break;

                        case "punching":
                            if (w != Under_control) // nieje to wormsik ktor� pou��va abilitu 
                            {
                                if (w.X_pos > X_pos) // cielen� wormsik stoj� na pravo
                                    w.X_velocity = 15;
                                else w.X_velocity = -15;  // cielen� wormsik stoj� na �avo
                                w.Y_velocity= 18;
                                w.Actualize_health(50); // Aktualiz�cia �ivota worms�ka ( "punching" vezme polovicu �ivota wormsika)
                                w.Stable = false;
                                cam.Update_object_to_track((Physics_object)w); // kameru fokusujeme na zasiahnut�ho wormsika
                            }
                            break;
                    }
                }
            }
        }
    }
    private void animation_of_aiming()
    {
        Vector3 world_postition = Camera.main.ScreenToWorldPoint(Input.mousePosition); // Pozicia mi�ky

        // V�po�et zlo�iek vektoru zameriava�a wormsika a uhlu vzhladom k vodorvnej rovine
        float X_vector = (world_postition.x - Under_control.X_pos);
        float Y_vector = (world_postition.y - Under_control.Y_pos);
        float angle_of_firing = Mathf.Atan2(Y_vector, X_vector) * (180 / Mathf.PI);

        //Aktualiz�cia obr�zku worms�ka
        if (worm_sprite_render == null) // z�skavanie referencie na objekt SpriteRenderer
            worm_sprite_render = Under_control.GetComponentInChildren<SpriteRenderer>();
        animator.enabled = false; //pozastavenie anim�ci� (inak nefunguje zmena obr�zku pri zameriavan�)
        int lenght_of_angle = 180 / worm_aiming.Length; // rozsah uhlu pre jeden obr�zok z pola
        int index_of_aiming_worm = (int)((angle_of_firing + 90) / lenght_of_angle) - 1;
        if (X_vector >= 0) // pr�pad mierenia v pravo
        {
            Under_control.transform.localScale = new Vector3(-10, 10, 1); //zrkadlov� transform�cia obr�zku
            index_of_aiming_worm = (worm_aiming.Length - 1) - index_of_aiming_worm;
        }
        else // pr�pad mierenia do �ava
        {
            // prepo�et indexu do po�a obr�zkov
            if (angle_of_firing > 0)
                index_of_aiming_worm = (int)(Mathf.Abs(90 - angle_of_firing) / lenght_of_angle);
            else
                index_of_aiming_worm = (int)((angle_of_firing + 270) / lenght_of_angle) - 1;
            Under_control.transform.localScale = new Vector3(10, 10, 5); //zrkadlov� transform�cia obr�zku
        }
        if (index_of_aiming_worm >= 0 && index_of_aiming_worm <= 32) // kontrola na index
        {
            Sprite aim = worm_aiming[index_of_aiming_worm]; // indexovanie do pola obr�zkov
            worm_sprite_render.sprite = aim; // zmena obr�zku pri zameriavan�
        }
    }
    private void Create_damage(int x_pos, int y_pos, float radius_of_effect)
    {
        float End_angle = 2 * Mathf.PI;
        //iter�cia cez polomer kruhu explozie (po�iatok kruhu je na s�radniciach kol�zie bomby)
        for (int radius = 0; radius <= (int)radius_of_effect; radius++)
        {
            //Iter�cia cez uhol 
            for (float angle = 0; angle < End_angle; angle += End_angle / (radius_of_effect*12))
            {
                // Mo�n� umiestnenie pixelu
                float test_pos_X = x_pos + Mathf.Cos(angle) * radius;
                float test_pos_Y = y_pos + Mathf.Sin(angle) * radius;

                int X_matrix_pixel_index = (int)test_pos_X + Map_object.width; // konverzia na X-index do po�a "map_pixel"
                int Y_matrix_pixel_index = (int)test_pos_Y + Map_object.height; // konverzia na Y-index do po�a "map_pixel"

                if (Check_Indexes(X_matrix_pixel_index, Y_matrix_pixel_index)) //kontrola hran�c po�a
                {
                    if (Map_object.map_pixels[X_matrix_pixel_index, Y_matrix_pixel_index] == ground.grass ||
                        Map_object.map_pixels[X_matrix_pixel_index, Y_matrix_pixel_index] == ground.stone ||
                        Map_object.map_pixels[X_matrix_pixel_index, Y_matrix_pixel_index] == ground.dirt ||
                         Map_object.map_pixels[X_matrix_pixel_index, Y_matrix_pixel_index] == ground.cave)
                    { Map_consolidation(X_matrix_pixel_index, Y_matrix_pixel_index); } // Konsolid�cia mapy po explozi�
                }
            }
        }
    }
    //Pomocn� funkcia ktor� graficky aktulizuje mapu
    private void Map_consolidation(int X_pos_matrix, int Y_pos_matrix)
    {
        ground type_of_surface = Map_object.map_pixels[X_pos_matrix, Y_pos_matrix];
        Vector3Int position_of_tile = new Vector3Int(X_pos_matrix - Map_object.width, 
                                                    Y_pos_matrix - Map_object.height, 0);
        // Mazanie bloku z pr�slu�nej poz�cie a mapy
        switch (type_of_surface)
        {
            case ground.grass:
                Grass_map.SetTile(position_of_tile, null);            
                break;
            case ground.stone:
                Stone_map.SetTile(position_of_tile, null);
                break;
            case ground.dirt:
                Dirt_map.SetTile(position_of_tile, null);
                break;
            case ground.cave:
                Cave_map.SetTile(position_of_tile, null);
                break;
        }
        Air_map.SetTile(position_of_tile, Air);
        Map_object.map_pixels[X_pos_matrix, Y_pos_matrix] = ground.air; // nastavovanie pixelu na "vzduch" (ned�jde ku kolizi)
    }
    private bool Check_Indexes(int X_index, int Y_index)
    {
        return  X_index < 2 * Map_object.width && X_index > 0 &&
                Y_index < 2 * Map_object.height && Y_index> 0;
    }
    private void Calculate_trajectory_and_update_list() // V�po�et trajektorie projektilu
    {
        // Po�iatok v�strelu
        float origin_of_fire_X = Under_control.X_pos;
        float origin_of_fire_Y = Under_control.Y_pos;

        // Zbar� vystrel� v smere my�ky
        Vector3 world_postition = Camera.main.ScreenToWorldPoint(Input.mousePosition); // poz�cie vo svete

        // inicializ�cia objektu bomby
        Bomb_object bomb_firing= Instantiate(bomb, new Vector3(origin_of_fire_X, origin_of_fire_Y, -2), Quaternion.identity);
        bomb_firing.Tag = types_of_bomb.Clasic_bom; 
        float X_vector = (world_postition.x - origin_of_fire_X); // V�po�et X s�radnice trajektorie bomby
        float Y_vector = (world_postition.y - origin_of_fire_Y); // V�po�et Y s�radnice trajektorie bomby
        float angle_of_firing = Mathf.Atan2(Y_vector , X_vector) * (180 / Mathf.PI); // uhol trajektorie (vo�i vodorvnej osy)
        if (angle_of_firing > 90) { bomb_firing.transform.localScale = bomb_firing.transform.localScale * (-1); }
          float Magnitude = Mathf.Sqrt(X_vector * X_vector + Y_vector * Y_vector); // Normaliz�cia vektoru

        bomb_firing.X_velocity = (X_vector / Magnitude) * Under_control.current_fire_progress * 0.4F; // V�po�et X zlo�ky vektoru r�chlosti bomby
        bomb_firing.Y_velocity = (Y_vector / Magnitude) * Under_control.current_fire_progress * 0.4F; // V�po�et Y zlo�ky vektoru r�chlosti bomby
        bomb_firing.X_pos = origin_of_fire_X;
        bomb_firing.Y_pos = origin_of_fire_Y;
        bomb_firing.Stable = false;
        engine.Update_list(bomb_firing); // Aktualiz�cia listu fyzick�ch objektov o objekt bomby
        Physics_object projectile = bomb_firing.GetComponent<Physics_object>();
        cam.Update_object_to_track(projectile); // "Focus" kamery na objekt bomby
    }
    private void Initialize_teams_of_worms() // Funkcia ktor� inicializuje t�me v hre
    {
        float offset_of_spawn = 20F;
        //V�po�et miesta pre rozmiestnenie worms�kov
        float space_for_team = 2 * (Map_object.width - offset_of_spawn) / number_of_teams; // Miesto pre jeden t�m (v pixeloch)
        float space_for_worm = space_for_team / number_of_worms_in_team; // space for one worm at his team;
        for (int i = 0; i < number_of_teams; i++) // "spawning" worm�kov pre jednotliv� t�my
        {
            Team_object team = new Team_object(number_of_worms_in_team); // Inicializ�cia objektu t�mu
            float begining_of_the_spawning = -Map_object.width + offset_of_spawn + i * space_for_team;
            for (int j = 0; j < number_of_worms_in_team; j++)
            {
                float x_pos_of_spawn = begining_of_the_spawning + j * space_for_worm; // Poz�cia X "Spawningu" worms�ka
                float y_pos_of_spawn = Map_object.height - 70; // Poz�cia Y "Spawningu" worms�ka
                Vector3 position_of_allocated_worm = new Vector3(x_pos_of_spawn, y_pos_of_spawn, 0);

                WORM worm = Instantiate(new_worm, position_of_allocated_worm, Quaternion.identity); //Alok�cia worms�ka
                worm.transform.parent = this.transform;
                worm.X_pos = position_of_allocated_worm.x;
                worm.Y_pos = position_of_allocated_worm.y;
                worm.set_helth_bar_color(cam.list_of_colors_for_health_bar[i],
                                        cam.list_of_colors_for_health_bar[4]); // Nastavovanie farby t�mu
                engine.Update_list(worm); // Aktuliz�cia listu fyzick�ch objektov o worms�ka
                team.worms_in_team.Add(worm);
            }
            Teams_in_game.Add(team); // Pridanie t�mu do listu t�mov
        }
    }
    private void change_player() // Zmena t�mu ktor� je na rade
    {   
        player_on_move++;
        player_on_move %= number_of_teams;
        Team_object team = Teams_in_game[player_on_move];
        while (!team.is_team_alive()) // chcem zmenu na "�iv� t�m
        {
            player_on_move++;
            player_on_move %= number_of_teams;
            team = Teams_in_game[player_on_move];
        }

        if (Under_control != null)
        {
            // ak bol hra� �asova�om preru�en� po�as "na�ahovania" kanonu ---> resetovanie anim�cie a flagov
            animator.enabled = true;
            reset_animator();
            Under_control.current_fire_progress = 0F;
            Under_control.loading_shooting = false;
            Under_control.firing_the_weapon = false;
            Under_control.turn_on_off_arrow(false); // Vypnutie ��pky
        }

        Under_control = Teams_in_game[player_on_move].return_next_member(); // Aktuliz�cia objektu ktor� hr�� pr�ve kontroluje
        Under_control.turn_on_off_arrow(true); // zapnutie ��pky
        cam.Update_object_to_track((Physics_object)(Under_control)); // Aktualiz�cia "focusu" kamery
        // resetovanie flagov
        jumping = false;
        punching = false;
        vert_flame = false;
        gun_is_pulled = false;
        jetpacking = false;
        worm_sprite_render = null;
        animator = Under_control.GetComponentInChildren<Animator>(); // zmena referencie na objekt ktor� riadi animacie 
        animator.enabled = true;
    }
    private void jet_pack_function() // funkcia ktor� rie�i logiku animacie jetpacku
    {
        switch (jetpacking)
        {
            case true: // V tomto pr�pade vyp�name jetpack (dr�h�m stal�en�m alpha1)
                animator.SetBool("Jetpack", false);
                animator.SetBool("JetPack_fly", false);
                animator.SetBool("Flying", true); // hr�� pad�
                PlayerCompletedAction = true; // Hr�� vyu�il jetpack a tak ukon�il svoje kolo
                break;
            case false: // hr�� zapol jetpack
                if (!Under_control.jet_pack_used)
                {
                    animator.SetBool("Jetpack", true);
                    animator.SetBool("JetPack_fly", true);
                    Under_control.jet_pack_used = true; // wormsik vyu�il svoj jetpack (u� nem��e)
                    jetpacking = true;
                }
                break;
        }
    }
    private void change_wormsik()
    {
        Under_control.turn_on_off_arrow(false); // vypnutie �ipky nad wormsikom
        reset_animator(); // resetujem animator pri zmene wormsika
        Under_control = Teams_in_game[player_on_move].return_next_member(); // men�m objekt ktor� kontroluje hr��
        animator = Under_control.GetComponent<Animator>(); // zmena referncie na objekt animator
        animator.enabled = true;
        cam.Update_object_to_track((Physics_object)Under_control); // zmena objektu ktor� sleduje kamera
        Under_control.turn_on_off_arrow(true); // zapnutie �ipky nad nov�m wormsikom
    }
    private bool Someone_won() // Funkcia ktor� kontroluje �i niekto vyhral
    {
        int coun_alive = 0;
        foreach (Team_object t in Teams_in_game)
        { if (t.is_team_alive()) coun_alive++; }
        return coun_alive == 1;
    }
    private void reset_animator() // funkcia ktor� resetuje prametry objektu animator
    {
        if(animator != null)
            foreach (var parameter in animator.parameters) // resetovanie v�etk�ch anim�ci�
            {
                animator.SetBool(parameter.name, false);
            }
    }
}
