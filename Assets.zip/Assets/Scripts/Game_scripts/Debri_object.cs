using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Debri_object : Physics_object
{

    private void Start()
    {
        this.radius_of_interaction = 4;
        //na za�iatku maj� �lomky n�hodny vektor r�chlost�
        this.X_velocity = Random.Range(-5, 6);
        this.Y_velocity = Random.Range(-5, 6);
        this.friction = 0.7F;
        this.Bounce_number = 3;
        this.Stable = false;
    }

    protected override void rotate(float Y_vel, float X_vel)
    {   
        // na parametroch nez�le��
        // V pr�pade �lomkov je rot�cia n�hodn�
        foreach (Transform child in transform) // rot�cia pod-objektov (lep�� vizu�lny efekt)
        {
            float angle_in_degree = Random.Range(0, 181);
            child.rotation = Quaternion.Euler(new Vector3(0, 0, angle_in_degree)); 
        }
    }
    public override void Dispose() { Destroy(gameObject); }
    public override Action Dead_action() { /* Nerob ni� */ return Action.Debri; }
    public override void move_method(float x_vec, float y_vec)
    {
        transform.Translate(x_vec, y_vec, 0);
        this.X_pos += x_vec;
        this.Y_pos += y_vec;
        rotate(2,2); // rot�cia po posunu
    }
}
