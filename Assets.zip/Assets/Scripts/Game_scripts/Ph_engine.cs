using System.Collections.Generic;
using UnityEngine;

public class Ph_engine : MonoBehaviour
{
    public List<Physics_object> list_objektov;  //List fyzick�ch objektov (v�etky objekty ktor� podliehaj� fyzike)
    private float prev_time = 0F;   //�as od prech�dzaj�ceho �asov�ho ramcu aktuliz�cie
    private Procedural_Gen Map_object;    // Tento objekt mus� komunikova� s objektom zodpovedn� za logiku mapy (dektcia kolizi�)
    public Main_function main;  // Tento objekt mus� komunikova� s objektom zodpovedn� za logiku hry
    private float Gravity_magnitude = -2F; // Ve�kos� gravita�neho zr�chlenia
    private void Awake() //Vytvorenie referenci na objekt "Mapy"
    { Map_object = GameObject.Find("Procedural_generation").GetComponent<Procedural_Gen>(); }
    void Start()
    { list_objektov = new List<Physics_object>(); }

    public void Update_list(Physics_object obj) 
    { list_objektov.Add(obj); }

    void FixedUpdate()  // Update je volan� raz za jeden �asov� ramec
    {
        //Ulo�enie predch�dzaj�ceho �asu
        if (prev_time == 0) { prev_time = Time.time; }
        for (int i = 0; i < 10; i++) // T�to smy�ka je tu kv�li r�chlosti kreslenia obejktov (vo�i physic enginu)
        foreach (Physics_object obj in list_objektov)
        {
            //Poz�cia objektu
            float current_X_pos = obj.X_pos;
            float current_Y_pos = obj.Y_pos;

            //delta integra�n� �asov� krok
            float time_slice = Time.time - prev_time;

            //Aktualiz�cia zr�chlenia (sp�soben� gravit�ciou)
            obj.Y_acceleration = Gravity_magnitude;
;

            //Aktualiz�cia r�chlosti
            obj.X_velocity += obj.X_acceleration * time_slice;
            obj.Y_velocity += obj.Y_acceleration * time_slice;

            //Mo�n� nov� poloha objektu (�asov� integr�cia r�chlosti). Ale m��e nasta� kolize
            float potential_X = current_X_pos + obj.X_velocity * time_slice;
            float potential_Y = current_Y_pos + obj.Y_velocity * time_slice;
            //Restovanie zr�chlenia
            obj.Y_acceleration = 0F;
            obj.X_acceleration = 0F;
            obj.Stable = false;
            //Uhol v radi�noch vektoru pohybuj objektu (vo�i osy x)
            float angle = Mathf.Atan2(obj.Y_velocity, obj.X_velocity);
            float response_X = 0F;
            float response_Y = 0F;

            // Iter�cia cez pol-kruh okolo objektu a detekcia kol�zie
            bool colision = false;
                for (float radius = angle - Mathf.PI / 2.0F; radius < angle + Mathf.PI / 2.0F; radius += Mathf.PI / 5)
                {
                    // mo�n� nov� poloha objektu
                    float test_pos_X = current_X_pos + Mathf.Cos(radius) * obj.radius_of_interaction;
                    float test_pos_Y = current_Y_pos + Mathf.Sin(radius) * obj.radius_of_interaction;

                    int X_matrix_pixel_index = (int)test_pos_X + Map_object.width; // Konverzia na index X v poli map_pixel
                    int Y_matrix_pixel_index = (int)test_pos_Y + Map_object.height; // Konverzia na index y v poli map_pixel

                    // omezenie pohybu wormsika na r�mec ��rky a v��ky mapy
                    /*if ( (Mathf.Abs(test_pos_X) >= (Map_object.width - 5)) && obj.Dead_action() == Action.Nothing)
                        obj.X_velocity = 0;*/
                    // Kol�zia s texturou mapy (grass, dirt, stone)
                    if (Mathf.Abs(test_pos_X) <= (Map_object.width - 5) &&
                        Mathf.Abs(test_pos_Y) <= (Map_object.height - 5))
                    {
                        if (Map_object.map_pixels[X_matrix_pixel_index, Y_matrix_pixel_index] == ground.dirt ||
                            Map_object.map_pixels[X_matrix_pixel_index, Y_matrix_pixel_index] == ground.grass ||
                            Map_object.map_pixels[X_matrix_pixel_index, Y_matrix_pixel_index] == ground.stone)
                        {
                            //Aktualiz�cia vektoru kol�zie (normala k vektorom kolizie)
                            response_X += potential_X - test_pos_X;
                            response_Y += potential_Y - test_pos_Y;
                            colision = true;
                        }
                    }
                    else // pr�pad kolizie s okrajom mapy
                    {
                        response_X += potential_X - test_pos_X;
                        response_Y += potential_Y - test_pos_Y;
                        colision = true;
                        // worms�k sa msu� zastvi� na okraji mapy (inak bug v texture)
                        if (obj.Dead_action() == Action.Nothing && Mathf.Abs(test_pos_X) > (Map_object.width - 5))
                        {
                            colision = false;
                            obj.X_velocity = 0;
                            // worms�k pad� voln�m p�dom 
                        }
                    }
                }

            float Velocit_magnitude = 3F;
            if (colision)
            {
                    obj.Stable = true; 
                    // V�po�et amplit�dy vektoru r�chlosti a v�po�et vektoru odozvy
                    Velocit_magnitude = Mathf.Sqrt(obj.X_velocity * obj.X_velocity + obj.Y_velocity * obj.Y_velocity);
                    float Response_vec_magnitude = Mathf.Sqrt(response_X*response_X + response_Y*response_Y);
                    //V�po�et vektoru "odrazu" pomocou vektoru odozvy a vektoru r�chlosti
                    float help = obj.X_velocity + (response_X / Response_vec_magnitude) +
                                 obj.Y_velocity + (response_Y / Response_vec_magnitude);

                    obj.X_velocity = obj.friction * (Gravity_magnitude * help * (response_X / Response_vec_magnitude) + obj.X_velocity);
                    obj.Y_velocity = obj.friction * (Gravity_magnitude * help * (response_Y / Response_vec_magnitude) + obj.Y_velocity);

                    //"Odr�anie" objektu
                    if (obj.Bounce_number > 0) 
                    {
                        obj.Bounce_number -= 1;
                        if (obj.Bounce_number == 0)  //Ak je "Bounce_number" rovn� nule tak je to "dead" objekt
                            { obj.Is_dead = true; }
                    }

            }
            else // Ak nejde o kol�ziu --> tak aktualizujeme polohu
            {
                    obj.Stable = false;
                    obj.move_method(obj.X_velocity * time_slice, obj.Y_velocity * time_slice);                    
            }
            if (Velocit_magnitude < 0.2F) 
            {
                    obj.Stable = true;
                    obj.X_velocity = 0;
                    obj.Y_velocity = 0;
            }
        }
        //Aktualiz�cia �asu
        prev_time = Time.time;
        do_dead_action(); // Pred zmazan�m "dead" objektov --> vykonaj ich posledn� akciu pri evente "is dead"
        Delete_dead_objects(); // Zmazanie objektov ktor� su "dead"
    }

    private void do_dead_action() //  "Dead" (posledn�) akcia objektu pred zamzan�m
    {
        for (int i = 0; i < list_objektov.Count; i++)
        {
            Physics_object O = list_objektov[i];
            if(O.Is_dead) // Ak je objekt mrtvy tak vykonej jeho akciu
            {
                switch (O.Dead_action())
                {
                    case Action.Booom:
                        //Volanie funkcie zodpovednej z� logiku bomby (pri kol�zi�)
                        main.Bomb_function(O);
                        break;
                }
            }
        }
    }
    private void Delete_dead_objects() // Funkcia ktor� ma�e "dead" objekty zo zoznamu
    {
        List<Physics_object> new_list = new List<Physics_object>();
        for (int i = 0; i < list_objektov.Count; i++)
        {
            Physics_object O = list_objektov[i];
            if (!O.Is_dead) { new_list.Add(O); }
            else { O.Dispose(); } // Mazanie "dead" objektov
        }
        list_objektov = new_list; // v�mena zoznamov za "nov�" (bez "dead" objektov)
    }
    public bool Check_if_objects_are_stable() // Kontrola stability objektov
    {
        bool stability = true;
        foreach (Physics_object obj in list_objektov)
        {
            if (!obj.Stable) { stability = false; break; }
        }
        return stability;
    }
}
