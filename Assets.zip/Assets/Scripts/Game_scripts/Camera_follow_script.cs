using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;
using UnityEngine.Tilemaps;


public class Camera_follow_script : MonoBehaviour
{
    [SerializeField] Canvas canv;
    [SerializeField] Button Back_to_main_menu;
    [SerializeField] GameObject player_name; // Text n�zvu hr��ov
    [SerializeField] GameObject Timer; // �asova� hry
    [SerializeField] Tilemap Healt_of_temas; // Li�ty �ivota t�mov
    //different collors
    [SerializeField] RuleTile A_team_health_bar, B_team_health_bar, C_team_health_bar, D_team_health_bar, Empty_tile_bar; 
    public List<RuleTile> list_of_colors_for_health_bar;
    private TextMesh Text_of_timer; // odkaz na objekt textu �asova�a
    private TextMesh[] Player_names; // odkaz na objekt textu mien hr��ov 
    private GameObject[] players; // Gameobjecty ktor� dr�ia text
    private float Start_time;
    private Physics_object target;
    public Main_function main;
    private Camera cam;
    private Procedural_Gen Map_object; 
    private const float zoomed_scale_factor = 140F;
    private const float scale_factor_whole_screen = 345F;
    private Vector3 cam_position; // s��asn� poz�cia kamery
    public float Camera_x_offset; // Offset X meran� od stredu kamery
    public float Camera_y_offset; // Offset Y meran� od stredu kamery
    public float target_cam_X_pos = 0; // cielov� X-ov� s�radnica na ktro� by sa mala kamera pohn��
    public float target_cam_Y_pos = 0; // cielov� Y-ov� s�radnica na ktro� by sa mala kamera pohn��
    private float last_time_frame;
    public int X_pixel_size_Hbar = 1; 
    public int Y_pixel_size_Hbar = 5; // vy�ka v pixeloch jedneho health baru t�mu na obrazovke
    private bool cam_is_stable; //Boolean which determines if camera is stable
    private bool game_over_function_called = false; // flag ktor� hovor� �i u� funkcia bola zavolan�
    private GameObject Game_Over_Text; // text po skon�en� hry

    private void Start() 
    {
        //yyycam.aspect = 16 / 10; // Setting camera aspect ration 
        cam_position = new Vector3(0, 0, -10);
        cam.orthographicSize = scale_factor_whole_screen;
        Camera_y_offset = cam.orthographicSize; //setting width of camera
        Camera_x_offset = Camera_y_offset * cam.aspect; //seting hight of camera
        cam.transform.position = cam_position;  // at the beggining is the camera in the middle of the scene
        last_time_frame = Time.time; // updating time frame
        cam_is_stable = true; // v re�ime "whole screen" je kamera stabiln�
        Timer = Instantiate(Timer, transform.position, Quaternion.identity);
        Text_of_timer = Timer.GetComponent<TextMesh>();
        canv.transform.position = new Vector3(0, 0, 0);
        move_button();
        Back_to_main_menu.onClick.AddListener(OnClick);
    }
    public void Reset_timer() // resetovanie �asova�u
    {
        Start_time = Time.time;
        Text_of_timer.text = "20";
    }
    private void OnClick()
    {
        Loader_of_scenes.Load(Loader_of_scenes.Scenee.Main_Menu_Scene);
    }
    public void Actualize_timer() // Aktualiz�cia textu �asova�u
    { Text_of_timer.text = "Time left: " + Mathf.RoundToInt(Mathf.Abs(Time.time - Start_time - 20)).ToString() ;}
    private void Awake()
    {
        cam = GetComponent<Camera>();
        cam.orthographicSize = zoomed_scale_factor; // �k�lovac� faktor obrazovky
        Map_object = GameObject.Find("Procedural_generation").GetComponent<Procedural_Gen>(); // komunik�cia s mapou
    }
    public bool Timer_is_out() // Uplynul u� dan� �as na kolo ?
    {
        if (Timer.activeSelf) // po skon�en� hry je �asova� vypnut�
        {
            float Current_time = Time.time - Start_time;
            if (Current_time > 20F)
                return true;
            else
                return false;
        }
        return false;
    }
    private void Move_timer_and_names() // moving timer with screen
    {
        bool whole_screen_size = cam.orthographicSize == scale_factor_whole_screen; // je obrazovka v re�imu "whole screen"
        float x_offest = Y_pixel_size_Hbar; // offset x pre �asova� (v pixeloch)
        float scaling = scale_factor_whole_screen / zoomed_scale_factor; // O aky faktor sa maj� elementy pre�k�lova� ?
        switch (whole_screen_size) // zmena "scaling factoru" a offsetu pre �asova� v r�znych r�imoch
        {
            case true:
                Timer.transform.localScale = new Vector3(scaling, scaling, 1);
                x_offest = Y_pixel_size_Hbar + 5;
                break;
            case false:
                Timer.transform.localScale = new Vector3(1, 1, 1);
                break;
        }
        // pozicia �asova�u v z�vislosti na obrazovke a "health baroch" i
        float X_position = transform.position.x - Camera_x_offset + x_offest;
        float Y_position = transform.position.y + Camera_y_offset - (3 * Y_pixel_size_Hbar * main.number_of_teams);
        Timer.transform.position = new Vector3(X_position, Y_position, -1); // transforming postion

        for (int i = 0; i < players.Length; i++) // posun a pre�k�lovanie mien hr��ov na health bary
        {
            switch (whole_screen_size) // zmena "scaling factoru" pre texty v r�znych r�imoch
            {
                case true:
                    players[i].transform.localScale = new Vector3(scaling, scaling, -1);
                    break;
                case false:
                    players[i].transform.localScale = new Vector3(1, 1, -1);
                    break;
            }
            // v�po�et poz�cie mien hr��ov
            float X_pos_of_name= transform.position.x - Camera_x_offset + 2*x_offest;
            float Y_pos_of_nam = transform.position.y + Camera_y_offset - ((3 * Y_pixel_size_Hbar + 0.3F) * i);
            players[i].transform.position = new Vector3(X_pos_of_name, Y_pos_of_nam, -1); // nov� pozicia mena 
        }
    }
    public void Initialize_names() // z�skavanie referencie na objekt textov
    {
        Player_names = new TextMesh[main.Teams_in_game.Count]; // to�ko mien kolko t�mov
        players = new GameObject[main.Teams_in_game.Count]; // gameobjetky hr��ov (potrebn� kvoli trnasform�ci� polohy textu)
        for(int i = 0; i < main.Teams_in_game.Count; i++)
        {
            GameObject player = Instantiate(player_name, transform.position, Quaternion.identity);
            player.transform.parent = this.transform;
            TextMesh name_of_player = player.GetComponent<TextMesh>();

            switch (i) // maxim�lne 4 t�mi
            {
                case 0:
                    name_of_player.text = "A-team";
                    break;
                case 1:
                    name_of_player.text = "B-team";
                    break;
                case 2:
                    name_of_player.text = "C-team";
                    break;
                case 3:
                    name_of_player.text = "D-team";
                    break;
            }
            name_of_player.color = Color.black; // farba textu
            Player_names[i] = name_of_player; // ulo�enie odkazov na objekty do po�a
            players[i] = player;
        }
    }
    public void Update_object_to_track(Physics_object obj)
    {
        target = obj; // Nastavovanie cielov�ho objektu kamery (focus kamery)
        if (cam_is_stable) { Resize(); } // Ak je kamera stabiln� tak zmen�me r�im kamery
    }
    public void actualize_list_of_colors() // Inicializ�cia listu farieb
    {
        list_of_colors_for_health_bar = new List<RuleTile>() // Initializing list
             { A_team_health_bar, B_team_health_bar, C_team_health_bar, D_team_health_bar, Empty_tile_bar };
    }
    private void Update()
    {
        if (target != null && !cam_is_stable) // Pohyb len ak nieje stabilna a ak je s�streden� na nejak� objekt(wormsik,bomba..)
        {
            // Actualizing target postion
            target_cam_X_pos = target.X_pos; 
            target_cam_Y_pos = target.Y_pos;

            // Nov� poz�cia stredu kamery
            Vector3 new_pos = new Vector3(target_cam_X_pos, target_cam_Y_pos,
                                           cam.transform.position.z);
            Vector3 difference = new_pos - cam.transform.position;
            float time_value = (Time.time - last_time_frame) * 5F;
            Vector3 possible_new_pos = cam.transform.position + difference * time_value;
            /*Pred transl�ciou potrebujeme skontrolva�, �i kamer� je "vn�tri" mapy.
             Kontrolu mus�me robi� na ka�d� s�radnicu zvl᚝.*/
            if ((possible_new_pos.x) < Map_object.width - Camera_x_offset &&
                 (possible_new_pos.x) > (-1) * (Map_object.width - Camera_x_offset))
            {
                cam.transform.Translate(difference.x * time_value, 0, 0); // pohyb obrazovky v smere x
            }

            if ((possible_new_pos.y) < Map_object.height - Camera_y_offset &&
                 (possible_new_pos.y) > (-1) * (Map_object.height - Camera_y_offset))
            {
                cam.transform.Translate(0, difference.y * time_value, 0); // pohyb obrazovky v smere y
            }
            Initialize_health_bars(false); // Inicializ�cia �ivota t�mov
            Move_health_bar_with_screen(); // pohyb l�t �ivota s obrazovkou
            Move_timer_and_names(); // pohyb �asova�u s obrazovkou
            move_button();
        }
        last_time_frame = Time.time; // Aktuliz�cia posledn�ho �asu
    }
    public void Resize()
    {
        float cam_size = cam.orthographicSize;
        Initialize_health_bars(true); // mazanie star�ch pixelov pred �k�lovan�m
        switch (cam_size)
        {
            case scale_factor_whole_screen:
                cam.orthographicSize = zoomed_scale_factor; // nastavenie spr�vneho �k�lovania obrazovky
                cam_is_stable = false; // kamera nieje stabiln� v mode kedy je zameran� na ur�ity objekt
                break;
            case zoomed_scale_factor:
                cam.orthographicSize = scale_factor_whole_screen; // nastavenie spr�vneho �k�lovania obrazovky
                cam_is_stable = true; // kamera je stabilna v tomto r�ime
                transform.position = new Vector3(0, 0, -10); // nastvovanie novej poz�cie kamery (stred kamery le�� v po�iatku)
                break;
        }
        Camera_y_offset = cam.orthographicSize; //nastavovanie ��rky kamery
        Camera_x_offset = Camera_y_offset * cam.aspect; //nastavovanie v��ky kamery
        Move_health_bar_with_screen(); // Pohyb l�t �ivota s obrazovkou
        Initialize_health_bars(false); // Inicializ�cia nov�ch pixelov po �k�lovan�
        Move_timer_and_names(); // pohyb �asova�a po pre�k�lovan�
        move_button(); // pohy tla��tka po pre�k�lovan�
    }
    public void Call_Game_Over_Text(int player) // funckia ktor� je zodpovedn� za text po skon�en� s�boja worms�kov
    {
        if (!game_over_function_called) // chcem zavola� len raz (aby sme nezahltili pam� objektami)
        {
            Game_Over_Text = Instantiate(player_name, transform.position, Quaternion.identity);
            TextMesh text = Game_Over_Text.GetComponent<TextMesh>();
            switch (player) // znena farby a mena textu podla ��sla hr��a
            {
                case 0:
                    text.text = "Game Over \n A-team player won the game";
                    break;
                case 1:
                    text.text = "Game Over \n B-team player won the game";
                    break;
                case 2:
                    text.text = "Game Over \n C-team player won the game";
                    break;
                case 3:
                    text.text = "Game Over \n D-team player won the game";
                    break;
            }
            // Nastavovanie textu (velkos�, �t�l, umiestnenie)
            text.characterSize = 2;
            text.fontSize = 400;
            text.color = Color.red;
            text.anchor = TextAnchor.MiddleCenter;
            text.alignment = TextAlignment.Center;
            text.fontStyle = FontStyle.BoldAndItalic;
            if (!cam_is_stable)
                Resize(); // na konci chceme "whole screen" re��m
            Game_Over_Text.transform.position = new Vector3(0, 60, -1);
            game_over_function_called = true; // zmena flagu
            Timer.SetActive(false);
        }
    }
    public void Initialize_health_bars(bool clear_health_bars)
    {
        for (int i = 0; i < main.Teams_in_game.Count; i++)
        {
            Team_object team = main.Teams_in_game[i];
            RuleTile Color_of_team = list_of_colors_for_health_bar[i]; // farba t�mu (touto farbou bude inicializovan� li�ta �ivota)
            float total_health = 0F;
            foreach (WORM w in team.worms_in_team) // zis�ovanie celkov�ho �ivota v t�me
            { total_health += w.current_health_progress; }

            int bar_offset_y = 2; // y offsets medzi li�tami a hornou hranou obrazovky
            int bar_offset_X = Y_pixel_size_Hbar; // Offset li�ty �ivota od pravej hrany obrazovky
            float maximum_health = 2 * (Camera_x_offset - bar_offset_X); // Maxima�lna dl�ka li�ty �ivota (aby sedela do obrazovky)

            //Faktor ktor� hovor� (v percent�ch /100) ak� je stav �ivota
            float factor_of_total_life = total_health / (main.number_of_worms_in_team * 100F);
                                                                                             
            int normalized_to_pixel_maximum = (int)(maximum_health / X_pixel_size_Hbar); // normalizovan� maximum
            float current_health = factor_of_total_life * normalized_to_pixel_maximum; // S��asn� stav �ivota t�mu worms�kov
            if (clear_health_bars) // pr�pad mazanie l�t �ivota po pre�k�lovan�
            {
                for (int j = bar_offset_X; j < normalized_to_pixel_maximum; j++) // inicialit�cie "pr�zdnych" pixelov �ivota
                {
                    Vector3Int vector_of_tile = new Vector3Int(j, (int)(-1) * (i + (i + 1) * bar_offset_y), 0);
                    Healt_of_temas.SetTile(vector_of_tile, null);
                }
            }
            else // pr�pad inicializ�cie li�ty �ivota
            {
                for (int j = bar_offset_X; j < normalized_to_pixel_maximum; j++) // Inicializ�cia pixelov �ivota
                {
                    Vector3Int vector_of_tile = new Vector3Int(j, (int)(-1) * (i + (i + 1) * bar_offset_y), 0);
                    if ((int)j < Mathf.RoundToInt(current_health))
                    { Healt_of_temas.SetTile(vector_of_tile, Color_of_team); } // nastavovanie farby �ivota
                    else
                    { Healt_of_temas.SetTile(vector_of_tile, Empty_tile_bar); } // nastavovanie straten�ho �ivota
                }
            }
        }
    }
    public void Move_health_bar_with_screen()
    {
        bool whole_screen_size = cam.orthographicSize == scale_factor_whole_screen; // je obrazovka v re�imu "whole screen"
        float X_position = transform.position.x - Camera_x_offset; // horn� �av� roh obrzovky
        float Y_position = transform.position.y + Camera_y_offset;
        switch (whole_screen_size) // zmena "scaling factoru" a offsetu pre button v r�znych r�imoch
        {
            case true:
                float scaling = scale_factor_whole_screen / zoomed_scale_factor;
                Y_pixel_size_Hbar = (int) (5F*scaling);
                X_pixel_size_Hbar = (int) (1F*scaling);
                break;
            case false:
                Y_pixel_size_Hbar = 5;
                X_pixel_size_Hbar = 1;
                break;
        }
        Healt_of_temas.transform.localScale = new Vector3(X_pixel_size_Hbar, Y_pixel_size_Hbar, -2); // �k�lovanie "health barov"
        Vector3 postion_of_health_bar = new Vector3(X_position, Y_position, -1);
        Healt_of_temas.transform.position = postion_of_health_bar; // posun "Health barov" na spr�vnu poz�ciu

    }
    private void move_button() // funkcia ktor� men� velkos� a poz�ciu tla��tka
    {
        bool whole_screen_size = cam.orthographicSize == scale_factor_whole_screen; // je obrazovka v re�imu "whole screen"
        float X_position = transform.position.x + Camera_x_offset; // doln� prav� roh obrazovky
        float Y_position = transform.position.y - Camera_y_offset;
        switch (whole_screen_size) // zmena "scaling factoru" a offsetu pre button v r�znych r�imoch
        {
            case true:
                canv.transform.localScale = new Vector3(3, 2.5F, -2);
                X_position -= 120;
                Y_position += 90;
                break;
            case false:
                canv.transform.localScale = new Vector3(1, 1, -2);
                X_position -= 50;
                Y_position += 30;
                break;
        }
        canv.transform.position = new Vector3(X_position, Y_position, -2); // posun tla��tka
    }
}

