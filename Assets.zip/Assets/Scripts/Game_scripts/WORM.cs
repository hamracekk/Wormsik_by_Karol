using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.Tilemaps;

public enum States_of_worms {Standing, Walking, Flying, Aiming, Jetpacking }
public class WORM : Physics_object
{
    [SerializeField] Sprite ThumbStone;
    [SerializeField] GameObject arrow;
    [SerializeField] Tilemap FireLoad_Tile_map, Helth_Tile_map; // Matica pre �ivot a "na�ahovanie" zbrane
    [SerializeField] RuleTile Firing_tile;
    private SpriteRenderer SpR;
    private Animator W_anim;
    private RuleTile Health_tile, Empty_tile;
    private static float radius = 7F; // polomer interakce worms�ka s fyzick�mi objektami
    private static float frict = 0.2F; //trenie (strata energie pri kol�zi�)
    private int Tiles_fire_offset = 5; // "offset" matice "na�ahovania" zbrane od worms�ka
    private int Tile_health_offset = 7; //"offset" matice �ivota worms�ka od worms�ka
    public float current_fire_progress = 0; //V akom �t�diu je proces "na�ahovania" zbrane ?
    public bool firing_the_weapon = false; // Zbra� m� vyp�li�
    public static int maximum_progress_value = 100; //minim�lna hodnota "progress barov"
    public float current_health_progress = maximum_progress_value; // s��asn� stav �ivota (na za�iatku je rovn� maximu)
    public bool loading_shooting = false; // "Na�ahuje" worms�k kanon ?
    private float last_fire_weapon_progress = 0; //Stav na�ahovania kanonu po poslednom update (�asov� r�mec)
    public bool worm_is_dead; // je tento wormsik mrtvy ? (v zmysle �e �i m� nejak� �ivot)
    private Vector3 current_arrow_pos;
    private int direction = 1; //smer pohybu �ipky --> 1 hore a -1 je dole
    // flagy pre pou��vanie vybavenia (dookola sa m��e pou�iva� iba delo - zbra� ��slo 2 a punching)
    public bool jet_pack_used = false; 
    public bool vertcal_flame_used = false;
    

    private void Start()
    {
        this.transform.position = new Vector3(this.transform.position.x, this.transform.position.y, 2);
        this.radius_of_interaction = radius;
        this.friction = frict;
        progess_bar_Initialize(); //Nakreslenie �ivota nad worms�kom
        worm_is_dead = false;
        current_arrow_pos = transform.position + new Vector3(0, 20, -1);
        arrow = Instantiate(arrow, current_arrow_pos, Quaternion.identity); 
        arrow.SetActive(false);
        W_anim = GetComponent<Animator>(); // komunik�cia sobjektom anim�ci�
        SpR = GetComponentInChildren<SpriteRenderer>();
    }
    public override void Dispose() { Destroy(gameObject); } // odstranenie objektu z hry
    private void Update()
    {
        // Aktualiz�cia "na�ahovania zbrane"
        if (loading_shooting)
        {
            int lower_boundary = (int)last_fire_weapon_progress - maximum_progress_value/ 2;
            int upper_boundary = (int)current_fire_progress - maximum_progress_value / 2;
            // Aktulizujeme len ch�baj�ce pixely (r�chlos�)
            for (int i = lower_boundary; i <= upper_boundary; i++)
            {
                Vector3Int Fire_tile_vector = new Vector3Int(i, Tiles_fire_offset, 0);
                FireLoad_Tile_map.SetTile(Fire_tile_vector, Firing_tile);
            }
            //aktualiz�cia posledn�ho stavu "na�ahovania"
            last_fire_weapon_progress = current_fire_progress;
        }
        else // inak vyma� cel� "na�ahovanie" zbrane
        {
            for (int i = -maximum_progress_value / 2; i <= maximum_progress_value / 2; i++)
            {
                Vector3Int Fire_tile_vector = new Vector3Int(i, Tiles_fire_offset, 0);
                FireLoad_Tile_map.SetTile(Fire_tile_vector, null);
            }
        }

        if(W_anim != null && W_anim.enabled && !(bool)W_anim.GetBool("JetPack_fly"))
        {
            // ak ma wormsik "ve�k�" y-ov� zlo�ku a zarove� nem� jetpack r�chlosti tak pad� alebo let�
            // to umo�nuje meni� anim�cie aj ke� nieje pod kontrolou hr��a
            if (Mathf.Abs(this.Y_velocity) > 6 && W_anim != null) 
            {
                W_anim.SetBool("Flying", true);
                float magnitude = Mathf.Sqrt(this.Y_velocity * this.Y_velocity + this.X_velocity * this.X_velocity);
                if (magnitude > 12) // aby nerotoval pri skoku
                    rotate(this.Y_velocity, this.X_velocity);
            }
            else if (this.Stable == true) // ak je objekt stabiln� tak u� nepad� ani nelet�, tak�e zmen�me jeho anim�ciu
            {
                W_anim.SetBool("Flying", false);
                rotate(0,0); // worms�k m� nulov� rot�ciu ak je stabiln�
            }
        }
    }
    public override Action Dead_action()
    { /* Do something*/ return Action.Nothing; }
    public override void move_method(float x_vec, float y_vec)
    {
        transform.Translate(x_vec, y_vec, 0); // posun fyzick�ho objektu
        this.X_pos += x_vec;
        this.Y_pos += y_vec;
        if(arrow.activeSelf)
            arrow.transform.Translate(x_vec, y_vec, 0); // posun ��pky nad worms�kom
    }
    public void turn_on_off_arrow(bool turn_on) // zapnutie / vypnutie ��pky nad worms�kom
    {
        if (turn_on)
        {
            arrow.SetActive(true);
            current_arrow_pos = transform.position + new Vector3(0, 25, -1);
            arrow.transform.position = current_arrow_pos; // transform�cia poz�cie ��pky
        }
        else { arrow.SetActive(false); }
    }
    public void arrow_blicking()
    {
        Vector3 arrow_Current_position = arrow.transform.position;
        Vector3 distance_vector = arrow_Current_position - this.transform.position; // vzidalenos� od objektu worms�ka
        if (distance_vector.y > 35F) // zmena smeru --> smer dole
        { direction = -1; }
        else if (distance_vector.y < 25F) // zmena smeru --> smer hore
        { direction = 1; }
        arrow.transform.position += direction * new Vector3(0, 0.05F, 0); // zmena y-ov� pozicie ��pky (kmit� hore dole)
    }
    protected override void rotate(float Y_vel, float X_vel)
    {
        // v�po�et uhlu zakryvenia dr�hy
        if (X_vel != 0)
        {
            float tang_angle = Y_vel / X_vel;
            float angle = Mathf.Atan(tang_angle);
            float angle_in_degree = angle * (180 / Mathf.PI);
            if (this.X_velocity != 0F) // kontrola na delenie
                SpR.transform.rotation = Quaternion.Euler(new Vector3(0, 0, angle_in_degree)); // rotacia obr�zku wormsika
        }
        else
            SpR.transform.rotation = Quaternion.Euler(new Vector3(0, 0, 0)); 
    }
    public void set_helth_bar_color(RuleTile tile, RuleTile empty) // funkcia pre nastavenie farieb
    { Health_tile = tile; Empty_tile = empty; }
    public void progess_bar_Initialize()
    {
        /*Po�iatky mat�c �ivota/na�ahovania s� nad worms�kom. Iterujeme symtericky na obe 
         * strany s�radnice x (stred "baru" je presne nad worms�kom)
         * a offsetujeme y.ov� suradnicu vhodnou v��kou worms�ka + v��ka in�ch "load barov"*/
        for (int i = - maximum_progress_value/2; i <=  maximum_progress_value / 2;  i++)
        {
            Vector3Int Health_tile_vector = new Vector3Int(i, Tile_health_offset, 0);
            if (i <= current_health_progress - maximum_progress_value / 2)
            { Helth_Tile_map.SetTile(Health_tile_vector, Health_tile); } // nastavenie �ivota
            else { Helth_Tile_map.SetTile(Health_tile_vector, Empty_tile); } // nastavenie straty �ivota 
        }
    }
    public void Actualize_health( float health_taken)
    {
        if (!worm_is_dead) // Ak worms�k nieje mrtv� aktualizujeme jeho �ivot
        {
            current_health_progress -= health_taken;
            if (current_health_progress <= 0) 
            { 
                current_health_progress = 0F; // aktulizujeme �ivot na 0 a flag 
                worm_is_dead = true;
                // Zmen�m obr�zok wormsika na "ThumbStone"
                W_anim.enabled = false;// Pred zmenou obr�zku mus�m vypn�� animator
                SpR.sprite = ThumbStone;
                transform.localScale = new Vector3(0.5F, 0.5F, -1); // vhodn� velkos� obr�zka
            }
        }
        progess_bar_Initialize();
    }
}

