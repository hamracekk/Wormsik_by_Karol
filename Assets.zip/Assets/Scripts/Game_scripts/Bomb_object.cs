using UnityEngine;

public enum types_of_bomb { Clasic_bom, Vertical_flame } // tagy pre r�zne typy b�mb
public class Bomb_object : Physics_object
{
    private static float radius = 4F;
    private static float frict = 0.1F;
    //Bomba je okam�ite "dead" po n�raze tak�e preto je premnn� "bounce" nastaven� na 1 n�raz
    private static int bounce = 1;
    private types_of_bomb tagg;
    private Animator BombAnimator;
    public int radius_of_efect = 20;

    private void Start()
    {
        BombAnimator = GetComponent<Animator>(); // animator k dan�mu objektu
        this.radius_of_interaction = radius; // polomer interakcie s fyzick�mi objektami
        this.friction = frict;
        this.Bounce_number = bounce; // ko�ko kr�t sa bomba odraz� k�m umrie (1 x)
    }

    public types_of_bomb Tag // properties pre premennu tag
    {
        set
        {
            tagg = value;
            BombAnimator = GetComponent<Animator>(); // referencia na objekt anim�ci� pre instanciu typu bomba
            switch (value) // nastavovanie vlastnost� objektu pod�a tagu
            {
                case types_of_bomb.Clasic_bom:
                    BombAnimator.SetBool("VerFlame", false); // Vypnutie anim�cie "vertical flame"
                    BombAnimator.enabled = false; // animator je vypnut� kv�li rot�ci� bomby po�as pohybu
                    radius_of_efect = 30; // v��ie �kody ne� vertical flame
                    break;
                case types_of_bomb.Vertical_flame:
                    BombAnimator.SetBool("VerFlame", true); // spustenie anim�cie pre "vertical flame"
                    radius_of_efect = 20;
                    break;
            }
        }
        get
        { return tagg; }
    }

    public override Action Dead_action()
    { return Action.Booom; } //Akcia po "smrti"

    public override void Dispose() 
    {
        BombAnimator.enabled = true; // zapnutie anim�cie v�buchu
        BombAnimator.SetBool("Explosion", true); // Anim�cia explozie
        Destroy(gameObject, 0.5F); // Vymazanie objektu (pam�)
    }

    protected override void rotate(float Y_vel, float X_vel)
    {
        // V�po�et zakryvenia dr�hy
        float tang_angle = Y_vel / X_vel;
        float angle = Mathf.Atan(tang_angle);
        float angle_in_degree = angle * (180 / Mathf.PI);
        if(X_velocity != 0F)
            foreach (Transform child in transform) // Rot�cia poddru�en�ch objektov
            {
                child.rotation = Quaternion.Euler(new Vector3(0, 0, angle_in_degree));
            }
    }
    public override void move_method(float x_vec, float y_vec) // rot�cia a transl�cia objektu
    {
        transform.Translate(x_vec, y_vec, 0);
        this.X_pos += x_vec;
        this.Y_pos += y_vec;
        rotate(this.Y_velocity, this.X_velocity); // rot�cia pod�a trajektorie bomby
    }
}
