using UnityEngine;
using UnityEngine.UI;

public class Button_script_how_to : MonoBehaviour
{
    private Button back_to_amin_menu;

    private void Start()
    {
        back_to_amin_menu = this.GetComponent<Button>(); // referencia na tla��tko
        back_to_amin_menu.onClick.AddListener(OnClick); // tla�itko --> sp� do hlavn�ho menu
    }

    private void OnClick() // akcia tla��tka
    {
        Loader_of_scenes.Load(Loader_of_scenes.Scenee.Main_Menu_Scene);
    }
}
